import csv
import pandas as pd
import os
import re

def normalize_key(key):
    """Normalize header keys for flexible matching"""
    return re.sub(r'[^a-z0-9]', '', key.lower())

def find_header(headers, *keywords):
    """Find header column that contains all specified keywords"""
    for key in headers:
        norm = normalize_key(key)
        if all(k in norm for k in keywords):
            return key
    raise KeyError(f"No header found with keywords: {keywords}")

def safe_float(val):
    """Safely convert value to float, return None if invalid"""
    try:
        return float(val)
    except:
        return None

def load_h_codes(health_csv, env_csv):
    """Load H codes and statements from CSV files"""
    h_codes = {}
    
    # Load health hazard H codes
    try:
        with open(health_csv, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                h_codes[row['H Code']] = row['Hazard Statement']
    except FileNotFoundError:
        print(f"Warning: Health H codes CSV not found: {health_csv}")
    
    # Load environmental hazard H codes
    try:
        with open(env_csv, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                h_codes[row['H Code']] = row['Hazard Statement']
    except FileNotFoundError:
        print(f"Warning: Environmental H codes CSV not found: {env_csv}")
    
    return h_codes

def get_h_codes_for_category(hazard_type, category):
    """Map GHS categories to H codes"""
    h_code_mapping = {
        'Acute Toxicity - Oral': {
            'Category 1': ['H300'],
            'Category 2': ['H300'],
            'Category 3': ['H301'],
            'Category 4': ['H302']
        },
        'Acute Toxicity - Dermal': {
            'Category 1': ['H310'],
            'Category 2': ['H310'],
            'Category 3': ['H311'],
            'Category 4': ['H312']
        },
        'Acute Toxicity - Inhalation': {
            'Category 1': ['H330'],
            'Category 2': ['H330'],
            'Category 3': ['H331'],
            'Category 4': ['H332']
        },
        'Skin Corrosion/Irritation': {
            'Category 1': ['H314'],
            'Category 2': ['H315']
        },
        'Eye Damage/Irritation': {
            'Category 1': ['H318'],
            'Category 2': ['H319']
        },
        'Respiratory Sensitization': {
            'Category 1': ['H334']
        },
        'Skin Sensitization': {
            'Category 1': ['H317']
        },
        'Germ Cell Mutagenicity': {
            'Category 1A': ['H340'],
            'Category 1B': ['H340'],
            'Category 2': ['H341']
        },
        'Carcinogenicity': {
            'Category 1A': ['H350'],
            'Category 1B': ['H350'],
            'Category 2': ['H351']
        },
        'Reproductive Toxicity': {
            'Category 1A': ['H360'],
            'Category 1B': ['H360'],
            'Category 2': ['H361']
        },
        'STOT - Single Exposure': {
            'Category 1': ['H370'],
            'Category 2': ['H371'],
            'Category 3': ['H335', 'H336']  # Respiratory irritation or narcotic effects
        },
        'STOT - Repeated Exposure': {
            'Category 1': ['H372'],
            'Category 2': ['H373']
        },
        'Aspiration Hazard': {
            'Category 1': ['H304']
        },
        'Hazardous to the aquatic environment - acute': {
            'Acute 1': ['H400']
        },
        'Hazardous to the aquatic environment - chronic': {
            'Chronic 1': ['H410'],
            'Chronic 2': ['H411'],
            'Chronic 3': ['H412'],
            'Chronic 4': ['H413']
        },
        'Hazardous to the ozone layer': {
            'Category 1': ['H420']
        }
    }
    
    # Get H codes for the specific hazard type and category
    hazard_mapping = h_code_mapping.get(hazard_type, {})
    return hazard_mapping.get(category, [])

def load_chemical_data(csv_file):
    """Load acute toxicity data from CSV"""
    data = {}
    with open(csv_file, newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames

        # Dynamically match header columns
        internal_code_col = find_header(headers, 'internal', 'code')
        name_col = find_header(headers, 'chemical', 'name')
        oral_col = find_header(headers, 'oral', 'ld')
        dermal_col = find_header(headers, 'dermal', 'ld')
        inhal_col = find_header(headers, 'inhalation', 'lc')

        for row in reader:
            try:
                # Get the internal code as string, strip whitespace
                code = row[internal_code_col].strip()
                
                # Skip if code is empty
                if not code:
                    continue

                oral = safe_float(row[oral_col])
                dermal = safe_float(row[dermal_col])
                inhal = safe_float(row[inhal_col])

                if None in (oral, dermal, inhal):
                    raise ValueError("One or more toxicity values are invalid.")

                data[code] = {
                    'name': row[name_col].strip(),
                    'oral': oral,
                    'dermal': dermal,
                    'inhalation': inhal
                }
            except Exception as e:
                print(f"Skipping row due to error: {e}")
                continue
    return data

def load_health_hazard_data(csv_file):
    """Load health hazard data from CSV"""
    try:
        return pd.read_csv(csv_file)
    except FileNotFoundError:
        print(f"Warning: Health hazard CSV not found at: {csv_file}")
        return None

def load_environmental_hazard_data(csv_file):
    """Load environmental hazard data from CSV"""
    try:
        return pd.read_csv(csv_file)
    except FileNotFoundError:
        print(f"Warning: Environmental hazard CSV not found at: {csv_file}")
        return None

def calculate_ate(mixture, chem_data, endpoint):
    """Calculate Acute Toxicity Estimate (ATE) for mixture"""
    total = 0
    for code, percent in mixture.items():
        ate = chem_data[code][endpoint]
        if ate > 0:
            total += percent / ate
    return round(100 / total, 2) if total > 0 else None

def classify_ghs(ate, thresholds):
    """Classify GHS category based on ATE and thresholds"""
    for limit, category in thresholds:
        if ate <= limit:
            return category
    return "Not classified"

def get_user_formulation(chem_data):
    """Get formulation input from user"""
    print("\nEnter formulation by Internal Code and % (must total 100%)")
    print("Available codes:", sorted(list(chem_data.keys())[:10]), "..." if len(chem_data) > 10 else "")
    print("Type 'list' to see all available codes, or 'search <term>' to search for codes")
    
    mixture = {}
    total = 0
    
    while total < 100:
        try:
            code = input("Internal Code: ").strip()
            
            # Special commands
            if code.lower() == 'list':
                print("\nAll available codes:")
                for i, c in enumerate(sorted(chem_data.keys())):
                    print(f"{c:15} - {chem_data[c]['name']}")
                    if i > 0 and (i + 1) % 20 == 0:  # Show 20 at a time
                        if input("\nPress Enter to continue or 'q' to stop: ").lower() == 'q':
                            break
                continue
            
            if code.lower().startswith('search '):
                search_term = code[7:].lower()
                matches = [c for c in chem_data.keys() if search_term in c.lower() or search_term in chem_data[c]['name'].lower()]
                if matches:
                    print(f"\nFound {len(matches)} matches:")
                    for match in matches:
                        print(f"{match:15} - {chem_data[match]['name']}")
                else:
                    print("No matches found")
                continue
            
            if code not in chem_data:
                print(f"Invalid code: '{code}'")
                # Show similar codes
                similar = [c for c in chem_data.keys() if code.lower() in c.lower()]
                if similar:
                    print(f"Did you mean one of these? {similar[:5]}")
                continue
                
            percent = float(input(f"Percentage of {chem_data[code]['name']}: "))
            if percent <= 0 or total + percent > 100:
                print("Invalid percentage or exceeds 100%. Try again.")
                continue
            mixture[code] = percent
            total += percent
            print(f"Current total: {total}%")
        except ValueError:
            print("Invalid input. Try again.")
    
    return mixture

def calculate_acute_toxicity_classification(mixture, chem_data):
    """Calculate acute toxicity classification and return results"""
    
    thresholds = {
        'oral': [(5, 1), (50, 2), (300, 3), (2000, 4)],
        'dermal': [(50, 1), (200, 2), (1000, 3), (2000, 4)],
        'inhalation': [(0.5, 1), (2, 2), (10, 3), (20, 4)]
    }

    oral_ate = calculate_ate(mixture, chem_data, 'oral')
    dermal_ate = calculate_ate(mixture, chem_data, 'dermal')
    inhal_ate = calculate_ate(mixture, chem_data, 'inhalation')

    oral_class = classify_ghs(oral_ate, thresholds['oral']) if oral_ate else "Not Classified"
    dermal_class = classify_ghs(dermal_ate, thresholds['dermal']) if dermal_ate else "Not Classified"
    inhal_class = classify_ghs(inhal_ate, thresholds['inhalation']) if inhal_ate else "Not Classified"

    # Format rationale with ATE values
    oral_rationale = f"ATE: {oral_ate} mg/kg" if oral_ate else "Unable to calculate ATE"
    dermal_rationale = f"ATE: {dermal_ate} mg/kg" if dermal_ate else "Unable to calculate ATE"
    inhal_rationale = f"ATE: {inhal_ate} mg/L" if inhal_ate else "Unable to calculate ATE"

    return {
        'Acute Toxicity - Oral': (f"Category {oral_class}" if oral_class != "Not Classified" else "Not Classified", oral_rationale),
        'Acute Toxicity - Dermal': (f"Category {dermal_class}" if dermal_class != "Not Classified" else "Not Classified", dermal_rationale),
        'Acute Toxicity - Inhalation': (f"Category {inhal_class}" if inhal_class != "Not Classified" else "Not Classified", inhal_rationale)
    }

def calculate_environmental_hazard_classification(mixture, env_data, chem_data):
    """Calculate environmental hazard classification"""
    if env_data is None:
        return {
            'Hazardous to the aquatic environment - acute': ("Not classified", "Environmental data not available"),
            'Hazardous to the aquatic environment - chronic': ("Not classified", "Environmental data not available"),
            'Hazardous to the ozone layer': ("Not classified", "Not evaluated")
        }
    
    # Convert mixture keys to strings for matching
    env_data["Internal Code"] = env_data["Internal Code"].astype(str)
    mixture_str = {str(k): v for k, v in mixture.items()}
    
    # Filter data to only include ingredients in our mixture
    selected = env_data[env_data["Internal Code"].isin(mixture_str.keys())].copy()
    
    if selected.empty:
        return {
            'Hazardous to the aquatic environment - acute': ("Not classified", "No matching environmental data found"),
            'Hazardous to the aquatic environment - chronic': ("Not classified", "No matching environmental data found"),
            'Hazardous to the ozone layer': ("Not classified", "Not evaluated")
        }
    
    # Add percentage to selected data
    selected["Percentage"] = selected["Internal Code"].map(mixture_str)
    
    # GHS thresholds (as percentages, not decimals)
    acute_1_cutoff = 0.1  # 0.1%
    chronic_1_cutoff = 0.1  # 0.1%
    chronic_2_cutoff = 1.0  # 1.0%
    chronic_3_cutoff = 1.0  # 1.0%
    
    # Initialize weight sums
    acute_1_sum = 0.0
    chronic_1_sum = 0.0
    chronic_2_sum = 0.0
    chronic_3_sum = 0.0
    
    # Calculate weighted contributions
    ingredient_details = []
    for _, row in selected.iterrows():
        percent = row["Percentage"]
        chronic_cat = str(row["Aquatic Chronic Category"]).strip().lower()
        acute_cat = str(row["Aquatic Acute Category"]).strip().lower()
        m_factor = row["M-Factor"]
        m = float(m_factor) if pd.notnull(m_factor) else 1
        internal_code = row["Internal Code"]
        
        # Store ingredient details for rationale using internal code
        ingredient_details.append(f"Internal Code {internal_code} | Acute: {row['Aquatic Acute Category']} | Chronic: {row['Aquatic Chronic Category']}")
        
        # Store ingredient details for rationale using internal code
        #ingredient_details.append(f"Internal Code {internal_code}: {percent}% | Acute: {row['Aquatic Acute Category']} | Chronic: {row['Aquatic Chronic Category']}")

        # Acute
        if "acute 1" in acute_cat:
            acute_1_sum += percent * m
        
        # Chronic
        if "chronic 1" in chronic_cat:
            chronic_1_sum += percent * m
        elif "chronic 2" in chronic_cat:
            chronic_2_sum += percent
        elif "chronic 3" in chronic_cat:
            chronic_3_sum += percent
    
    # Apply GHS rules (worst case classification)
    acute_class = "Not classified"
    chronic_class = "Not classified"
    acute_rationale = "No components exceed classification thresholds"
    chronic_rationale = "No components exceed classification thresholds"
    
    if acute_1_sum >= acute_1_cutoff:
        acute_class = "Acute 1"
        acute_rationale = f"Sum of Acute 1 components: {acute_1_sum:.2f}% (≥ {acute_1_cutoff}%)"
    
    # Check chronic classification in order of severity
    if chronic_1_sum >= chronic_1_cutoff:
        chronic_class = "Chronic 1"
        chronic_rationale = f"Sum of Chronic 1 components: {chronic_1_sum:.2f}% (≥ {chronic_1_cutoff}%)"
    elif chronic_2_sum >= chronic_2_cutoff:
        chronic_class = "Chronic 2"
        chronic_rationale = f"Sum of Chronic 2 components: {chronic_2_sum:.2f}% (≥ {chronic_2_cutoff}%)"
    elif chronic_3_sum >= chronic_3_cutoff:
        chronic_class = "Chronic 3"
        chronic_rationale = f"Sum of Chronic 3 components: {chronic_3_sum:.2f}% (≥ {chronic_3_cutoff}%)"
    
    # Add ingredient breakdown to rationale
    ingredient_breakdown = "\n    Ingredient breakdown:\n    " + "\n    ".join(ingredient_details)
    acute_rationale += ingredient_breakdown
    chronic_rationale += ingredient_breakdown
    
    return {
        'Hazardous to the aquatic environment - acute': (acute_class, acute_rationale),
        'Hazardous to the aquatic environment - chronic': (chronic_class, chronic_rationale),
        'Hazardous to the ozone layer': ("Not classified", "Not evaluated")
    }

def perform_comprehensive_classification(product_name, mixture, chem_data, health_data, env_data, h_codes, base_dir):
    """Perform comprehensive GHS classification including acute toxicity, health hazards, and environmental hazards"""
    
    results = {}
    
    # Calculate acute toxicity classifications
    acute_results = calculate_acute_toxicity_classification(mixture, chem_data)
    results.update(acute_results)
    
    # Perform health hazard classification if data available
    if health_data is not None:
        # GHS cutoffs for classification
        cutoffs = {
            'Skin Corrosion/Irritation': {'Category 1': 1, 'Category 2': 10},
            'Eye Damage/Irritation': {'Category 1': 3, 'Category 2': 10},
            'Respiratory Sensitization': {'Category 1': 1},
            'Skin Sensitization': {'Category 1': 1},
            'Germ Cell Mutagenicity': {'Category 1A': 0.1, 'Category 1B': 0.1, 'Category 2': 1},
            'Carcinogenicity': {'Category 1A': 0.1, 'Category 1B': 0.1, 'Category 2': 1},
            'Reproductive Toxicity': {'Category 1A': 0.1, 'Category 1B': 0.1, 'Category 2': 1},
            'STOT - Single Exposure': {'Category 1': 10, 'Category 2': 10, 'Category 3': 20},
            'STOT - Repeated Exposure': {'Category 1': 10, 'Category 2': 10},
            'Aspiration Hazard': {'Category 1': 10}
        }

        # Convert mixture format for health hazard analysis
        ingredients = [{'Internal Code': code, 'Percentage': pct} for code, pct in mixture.items()]

        # Identify hazard columns
        hazard_columns = [col for col in health_data.columns if col not in ['Internal Code', 'Chemical Name', 'CAS Number']]
        hazard_types = list(set([col.split(',')[0].strip() for col in hazard_columns if 'Notes' not in col]))

        # Classification logic for health hazards
        for hazard in hazard_types:
            contributions = {}
            for ing in ingredients:
                row = health_data[health_data['Internal Code'] == ing['Internal Code']]
                if not row.empty:
                    category = row[hazard].values[0] if pd.notna(row[hazard].values[0]) else 'Not Classified'
                    note_column = f"Notes ({hazard.split(' - ')[0]})"
                    note = row[note_column].values[0] if note_column in row.columns and pd.notna(row[note_column].values[0]) else ""

                    if category != 'Not Classified':
                        if category not in contributions:
                            contributions[category] = {'pct': 0.0, 'notes': []}
                        contributions[category]['pct'] += ing['Percentage']
                        if note:
                            chem_name = row['Chemical Name'].values[0]
                            contributions[category]['notes'].append(f"{chem_name}: {note}")

            # Determine final classification based on cutoff
            classification = "Not Classified"
            rationale = "No components exceed classification thresholds."

            def cat_key(c):
                if 'Category' in c:
                    parts = c.split()
                    try:
                        if len(parts) == 2:
                            return int(parts[1])
                        elif len(parts) == 2 and parts[1].isalpha():
                            return {'A': 1, 'B': 2}.get(parts[1], 3)
                    except:
                        return 99
                return 100

            sorted_contribs = sorted(contributions.items(), key=lambda x: cat_key(x[0]))

            for cat, values in sorted_contribs:
                cutoff = cutoffs.get(hazard, {}).get(cat, None)
                if cutoff is not None and values['pct'] >= cutoff:
                    classification = cat
                    rationale = "; ".join(values['notes']) if values['notes'] else "Meets cutoff by percentage."
                    break

            results[hazard] = (classification, rationale)
    else:
        print("⚠️  Health hazard data not available - only acute toxicity classification performed")

    # Perform environmental hazard classification
    env_results = calculate_environmental_hazard_classification(mixture, env_data, chem_data)
    results.update(env_results)

    # Define the desired order for output
    health_hazard_order = [
        'Acute Toxicity - Oral',
        'Acute Toxicity - Dermal', 
        'Acute Toxicity - Inhalation',
        'Skin Corrosion/Irritation',
        'Eye Damage/Irritation',
        'Respiratory Sensitization',
        'Skin Sensitization',
        'Germ Cell Mutagenicity',
        'Carcinogenicity',
        'Reproductive Toxicity',
        'STOT - Single Exposure',
        'STOT - Repeated Exposure',
        'Aspiration Hazard'
    ]
    
    environmental_hazard_order = [
        'Hazardous to the aquatic environment - acute',
        'Hazardous to the aquatic environment - chronic',
        'Hazardous to the ozone layer'
    ]

    # Save comprehensive results
    output_filename = os.path.join(base_dir, f"Health_&_Environmental_Hazards_classification_result_{product_name}.txt")

    with open(output_filename, "w", encoding="utf-8") as f:
        f.write(f"=== COMPREHENSIVE GHS CLASSIFICATION REPORT ===\n")
        f.write(f"Product: {product_name}\n")
        f.write("=" * 60 + "\n\n")
        
        # Write Health Hazards section
        f.write("1. HEALTH HAZARDS\n")
        f.write("-" * 40 + "\n")
        
        # Write health hazard results in specified order
        for hazard in health_hazard_order:
            if hazard in results:
                cat, rationale = results[hazard]
                f.write(f"{hazard}:\n  Classification: {cat}\n")
                
                # Add H codes if classification is not "Not Classified"
                if cat != "Not Classified":
                    # Extract category from classification string
                    category_for_h_code = cat
                    if "Category " in cat:
                        category_for_h_code = cat  # Keep full "Category X" format
                    h_code_list = get_h_codes_for_category(hazard, category_for_h_code)
                    
                    if h_code_list:
                        f.write(f"  H Codes: {', '.join(h_code_list)}\n")
                        # Add H code statements
                        for h_code in h_code_list:
                            if h_code in h_codes:
                                f.write(f"    {h_code}: {h_codes[h_code]}\n")
                            else:
                                f.write(f"    {h_code}: [Statement not found]\n")
                
                f.write(f"  Rationale: {rationale}\n\n")
        
        # Write any remaining health hazards not in the predefined order
        for hazard, (cat, rationale) in results.items():
            if hazard not in health_hazard_order and hazard not in environmental_hazard_order:
                f.write(f"{hazard}:\n  Classification: {cat}\n")
                
                # Add H codes if classification is not "Not Classified"
                if cat != "Not Classified":
                    # Extract category from classification string
                    category_for_h_code = cat
                    if "Category " in cat:
                        category_for_h_code = cat  # Keep full "Category X" format
                    h_code_list = get_h_codes_for_category(hazard, category_for_h_code)
                    if h_code_list:
                        f.write(f"  H Codes: {', '.join(h_code_list)}\n")
                        # Add H code statements
                        for h_code in h_code_list:
                            if h_code in h_codes:
                                f.write(f"    {h_code}: {h_codes[h_code]}\n")
                
                f.write(f"  Rationale: {rationale}\n\n")
        
        # Write Environmental Hazards section
        f.write("\n2. ENVIRONMENTAL HAZARDS\n")
        f.write("-" * 40 + "\n")
        
        # Write environmental hazard results in specified order
        for hazard in environmental_hazard_order:
            if hazard in results:
                cat, rationale = results[hazard]
                f.write(f"{hazard}:\n  Classification: {cat}\n")
                
                # Add H codes if classification is not "Not classified"
                if cat != "Not classified":
                    h_code_list = get_h_codes_for_category(hazard, cat)
                    if h_code_list:
                        f.write(f"  H Codes: {', '.join(h_code_list)}\n")
                        # Add H code statements
                        for h_code in h_code_list:
                            if h_code in h_codes:
                                f.write(f"    {h_code}: {h_codes[h_code]}\n")
                            else:
                                f.write(f"    {h_code}: [Statement not found]\n")
                
                f.write(f"  Rationale: {rationale}\n\n")

    print(f"✅ Comprehensive classification results saved to:\n{output_filename}")
    return output_filename

def main():
    """Main function to run the comprehensive GHS classification tool"""
    print("=== COMPREHENSIVE GHS CLASSIFICATION TOOL WITH H CODES ===")
    print("This tool performs classification for:")
    print("1. Health Hazards (Acute Toxicity + Other Health Hazards)")
    print("2. Environmental Hazards")
    print("3. Includes H codes and hazard statements")
    
    # File paths - adjust these as needed
    base_dir = r'C:\Users\KAVI\Desktop\Acute Toxicity'
    acute_toxicity_csv = os.path.join(base_dir, 'Solvent_data_acute_toxicity.csv')
    health_hazard_csv = os.path.join(base_dir, 'health_hazard_data.csv')
    environmental_hazard_csv = os.path.join(base_dir, 'Environmental_hazard_data.csv')
    health_h_codes_csv = os.path.join(base_dir, 'Health_Hazards_H_Code.csv')
    env_h_codes_csv = os.path.join(base_dir, 'Environmental_Hazards_H_Code.csv')
    
    # Check if directory and files exist
    print(f"\nChecking directory: {base_dir}")
    if not os.path.exists(base_dir):
        print(f"❌ Directory not found: {base_dir}")
        return
    
    print("Directory found ✓")
    
    # List all files in the directory for debugging
    print(f"\nFiles in directory:")
    try:
        all_files = os.listdir(base_dir)
        for file in all_files:
            print(f"  - {file}")
    except Exception as e:
        print(f"❌ Error listing directory contents: {e}")
        return
    
    # Check each required file
    files_to_check = [
        ("Acute toxicity", acute_toxicity_csv, True),
        ("Health hazard", health_hazard_csv, False),
        ("Environmental hazard", environmental_hazard_csv, False),
        ("Health H codes", health_h_codes_csv, False),
        ("Environmental H codes", env_h_codes_csv, False)
    ]
    
    for file_type, file_path, required in files_to_check:
        if os.path.exists(file_path):
            print(f"{file_type} CSV found ✓")
        else:
            if required:
                print(f"❌ {file_type} CSV not found: {os.path.basename(file_path)}")
                print("Please check the filename and ensure it exists in the directory.")
                return
            else:
                print(f"⚠️  {file_type} CSV not found (optional): {os.path.basename(file_path)}")
    
    # Load H codes
    print("\nLoading H codes...")
    h_codes = load_h_codes(health_h_codes_csv, env_h_codes_csv)
    print(f"✓ Loaded {len(h_codes)} H codes")
    
    # Load data
    print("\nLoading acute toxicity data...")
    try:
        chem_data = load_chemical_data(acute_toxicity_csv)
    except Exception as e:
        print(f"❌ Error loading acute toxicity data: {e}")
        import traceback
        traceback.print_exc()
        return
    
    if not chem_data:
        print("❌ No valid chemical data loaded. Check acute toxicity CSV format and content.")
        return
    
    print(f"✓ Loaded {len(chem_data)} chemicals from acute toxicity data")

    print("Loading health hazard data...")
    health_data = None
    if os.path.exists(health_hazard_csv):
        health_data = load_health_hazard_data(health_hazard_csv)
        if health_data is not None:
            print(f"✓ Loaded health hazard data with {len(health_data)} rows")
    
    print("Loading environmental hazard data...")
    env_data = None
    if os.path.exists(environmental_hazard_csv):
        env_data = load_environmental_hazard_data(environmental_hazard_csv)
        if env_data is not None:
            print(f"✓ Loaded environmental hazard data with {len(env_data)} rows")

    # Get user input
    product_name = input("\nEnter product name: ").strip()
    mixture = get_user_formulation(chem_data)

    print(f"\n=== Processing {product_name} ===")
    
    # Perform comprehensive classification
    output_file = perform_comprehensive_classification(product_name, mixture, chem_data, health_data, env_data, h_codes, base_dir)
    
    print(f"\n=== Classification Complete ===")
    print(f"Comprehensive classification results with H codes saved to:\n{output_file}")

if __name__ == "__main__":
    main()